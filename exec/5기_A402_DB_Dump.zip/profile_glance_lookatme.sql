-- MySQL dump 10.13  Distrib 8.0.23, for Win64 (x86_64)
--
-- Host: 52.79.113.173    Database: profile_glance
-- ------------------------------------------------------
-- Server version	8.0.26-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `lookatme`
--

DROP TABLE IF EXISTS `lookatme`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lookatme` (
  `lookatme_id` int NOT NULL AUTO_INCREMENT,
  `category_id` int NOT NULL,
  `user_id` int NOT NULL,
  `title` varchar(100) NOT NULL,
  `content` varchar(300) NOT NULL,
  `video` varchar(200) NOT NULL,
  `thumbnail` varchar(200) DEFAULT NULL,
  `view` int DEFAULT NULL,
  `video_like` int DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`lookatme_id`),
  KEY `FK_category_TO_lookatme_category_id` (`category_id`),
  KEY `FK_user_TO_lookatme_user_id` (`user_id`),
  CONSTRAINT `FK_category_TO_lookatme_category_id` FOREIGN KEY (`category_id`) REFERENCES `category` (`category_id`),
  CONSTRAINT `FK_user_TO_lookatme_user_id` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lookatme`
--

LOCK TABLES `lookatme` WRITE;
/*!40000 ALTER TABLE `lookatme` DISABLE KEYS */;
INSERT INTO `lookatme` VALUES (8,1001,18,'알고리즘 풀이 영상!','알고리즘 풀이 영상입니다!\n백준 2618번 입니다~!\n잘 부탁드려요!','20210817084428Jeus.mp4','20210817084428Jeus.jpg',27,NULL,'2021-08-17 08:44:28'),(10,3011,17,'굴렁쇠 토끼 따라 그리기','팀 굴렁쇠\n우리의 굴렁쇠를 굴리는 토끼그림 그리기','20210817084955민동.mp4','20210817084955민동.jpg',40,NULL,'2021-08-17 08:49:55'),(11,1001,19,'코드위즈 실습','SSAFY 스타트캠프 때 진행했던 에코 챌린지 입니다.','20210817085229은고.mp4','20210817085229은고.jpg',6,NULL,'2021-08-17 08:52:29'),(12,3010,16,'곱창 요리 냠냠','맛있는 곱창 냠냠','20210817085910sxxnweek.mp4','20210817085910sxxnweek.jpg',20,NULL,'2021-08-17 08:59:10'),(13,1001,19,'미니게임 제작','착한 젤리는 구출하고 나쁜 젤리는 피하는 \'보건교사 안은영\' 게임을 개발해보았읍니다.','20210817085958은고.mp4','20210817085958은고.jpg',4,NULL,'2021-08-17 08:59:58'),(14,1001,16,'개발 참 쉽죠??','개발 참 쉽죠??','20210817110844sxxnweek.mp4','20210817110844sxxnweek.jpg',5,NULL,'2021-08-17 11:08:44'),(15,3010,19,'[일상 vlog] 설날에 전 부치기!','설날을 맞아 가족들과 전을 부쳐봤어요~ 타임랩스로 찍으니까 더 재밌네요!','20210817111220은고.mp4','20210817111220은고.jpg',10,NULL,'2021-08-17 11:12:20'),(16,3009,18,'라스베가스 여행기','라스베가스 여행기 입니다~','20210817111313Jeus.mp4','20210817111313Jeus.jpg',5,NULL,'2021-08-17 11:13:13'),(17,1001,16,'소스 트리 사용법','소스트리 장인 굴렁즈','20210817111821sxxnweek.mp4','20210817111821sxxnweek.jpg',7,NULL,'2021-08-17 11:18:21'),(21,1001,19,'자기소개 영상입니다','소프트웨어 개발자를 꿈꾸는 정은교입니다!','20210818080934은고.mp4','20210818080934은고.jpg',19,NULL,'2021-08-18 08:09:34');
/*!40000 ALTER TABLE `lookatme` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-08-19 20:19:09
