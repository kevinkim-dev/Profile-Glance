-- MySQL dump 10.13  Distrib 8.0.23, for Win64 (x86_64)
--
-- Host: 52.79.113.173    Database: profile_glance
-- ------------------------------------------------------
-- Server version	8.0.26-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `user_id` int NOT NULL AUTO_INCREMENT,
  `user_name` varchar(50) NOT NULL,
  `user_email` varchar(100) NOT NULL,
  `user_nickname` varchar(100) NOT NULL,
  `user_password` varchar(100) NOT NULL,
  `major1` varchar(100) DEFAULT NULL,
  `major2` varchar(100) DEFAULT NULL,
  `user_phone` varchar(50) NOT NULL,
  `is_admin` tinyint(1) DEFAULT '0',
  `user_img` varchar(200) DEFAULT NULL,
  `company_like` int DEFAULT NULL,
  `birth` varchar(100) NOT NULL,
  `portfolio1` varchar(100) DEFAULT NULL,
  `portfolio2` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'관리자','admin@admin.com','관리자','{bcrypt}$2a$10$38RpvMN73SeKc/dNFRX03.55MFzQX9RGHMNmTW65/y9CBlhrpV3sW','','','01000000000',1,'noimage.png',0,'2021-07-12',NULL,NULL),(14,'김동훈','ehdgns5212@gmail.com','동훈','{bcrypt}$2a$10$38RpvMN73SeKc/dNFRX03.55MFzQX9RGHMNmTW65/y9CBlhrpV3sW','소프트웨어','','01036755901',0,'ehdgns5212@gmail.com.jpg',0,'1997-01-31',NULL,NULL),(15,'김승현','seankim95@naver.com','kevinkim','{bcrypt}$2a$10$38RpvMN73SeKc/dNFRX03.55MFzQX9RGHMNmTW65/y9CBlhrpV3sW','전자','컴퓨터','01090101474',0,'seankim95@naver.com.jpg',2,'1995-10-30','',''),(16,'권순주','sxxnweek@gmail.com','sxxnweek','{bcrypt}$2a$10$38RpvMN73SeKc/dNFRX03.55MFzQX9RGHMNmTW65/y9CBlhrpV3sW','','','01086897704',0,'sxxnweek@gmail.com.jpg',0,'1996-02-26','https://github.com/ssoonD',NULL),(17,'민동엽','dymin01@naver.com','민동','{bcrypt}$2a$10$38RpvMN73SeKc/dNFRX03.55MFzQX9RGHMNmTW65/y9CBlhrpV3sW','컴퓨터공학','','01034633375',0,'dymin01@naver.com.jpg',1,'1994-06-10','https://github.com/dymin01',''),(18,'심재우','jw_shim@naver.com','Jeus','{bcrypt}$2a$10$38RpvMN73SeKc/dNFRX03.55MFzQX9RGHMNmTW65/y9CBlhrpV3sW','SW','','01090998926',0,'jw_shim@naver.com.jpg',2,'1994-11-12','https://github.com/jeus1112',NULL),(19,'정은교','gyoforit@gmail.com','은고','{bcrypt}$2a$10$38RpvMN73SeKc/dNFRX03.55MFzQX9RGHMNmTW65/y9CBlhrpV3sW','','','01043051995',0,'gyoforit@gmail.com.jpg',0,'1995-01-11','https://github.com/gyoforit',NULL),(20,'SSAFY','ssafy@ssafy.com','SSAFY','{bcrypt}$2a$10$38RpvMN73SeKc/dNFRX03.55MFzQX9RGHMNmTW65/y9CBlhrpV3sW','','','01000000000',0,'ssafy@ssafy.com.jpg',0,'2021-07-12',NULL,NULL),(21,'김싸피','ssafykim@ssafy.com','김싸피','{bcrypt}$2a$10$avrbwp9AjjawGTx/pF9.ge38PsBFvxJJKFGOaoO.zBMH.y3JytToy','','','01012341234',0,'ssafykim@ssafy.com.jpg',0,'2021-08-18',NULL,NULL),(23,' 준생','chijoon@gmail.com','취준생','{bcrypt}$2a$10$ip/8V9AH/zobMdWLntqJs.J2j9SE7In.nKCTqG.HD5Ff3Sp1h8saW','','','01012341234',0,'chijoon@gmail.com.jpg',0,'2021-08-18',NULL,NULL),(24,'철수','ironwater@gmail.com','철수','{bcrypt}$2a$10$qGtRrGQ7kcrw9D/CfCzKIOlz.Zsi/qHI3HkLGLe0f51F4T88aqPWe','','','01012341234',0,'ironwater@gmail.com.jpg',0,'2021-08-18',NULL,NULL),(25,'영희','zerohappy@gmail.com','영희','{bcrypt}$2a$10$cF6efZID/6dEBV33soVNCO5qxBanP1CioHF6zol/nCxb2HdyYPYDG','','','01012341234',0,'zerohappy@gmail.com.jpg',0,'2021-08-18',NULL,NULL);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-08-19 20:19:07
